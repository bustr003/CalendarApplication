package edu.csusm.cscalendarapp;

public class EventObject {

    String eventName;

    public EventObject(){

    }

    public EventObject(String eventName) {
        this.eventName = eventName;
    }

    public String getEventName() {
        return eventName;
    }
}
