package edu.csusm.cscalendarapp;

import android.app.Activity;
import android.app.ActivityOptions;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import edu.csusm.cscalendarapp.EventObject;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class EventPop extends Activity {

    DatabaseReference databaseEvents;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("events");
        myRef.setValue("Hello World!");

        setContentView(R.layout.event_popup);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(width*.8),(int)(height*.6));

        Button sub = (Button)findViewById(R.id.submit_event);
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String eName;
                EditText eNameEdit = (EditText) findViewById(R.id.event_name);
                eName =  eNameEdit.getText().toString();

                if (eName.matches("")){
                    Toast.makeText(getApplicationContext(), "Please Enter All Information", Toast.LENGTH_LONG).show();
                }else{
                    //String id = databaseEvents.push().getKey();

                    //EventObject event = new EventObject(eName);

                    //databaseEvents.child(id).setValue(event);

                    Toast.makeText(getApplicationContext(), "Event Added", Toast.LENGTH_LONG).show();

                    finish();
                }


            }

        });

    }
}
